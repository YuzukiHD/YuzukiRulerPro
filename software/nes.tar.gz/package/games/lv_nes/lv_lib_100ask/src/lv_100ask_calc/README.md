
<h1 align="center"> lv_100ask_calc</h1>

<p align="center">
<img src="./lv_100ask_calc_demo.gif">
</p>
<p align="center">
lv_100ask_calc is a lvgl calculator.
</p>


**English** | [中文](./README_zh.md) |


# Introduction
**lv_100ask_calc** features：

- Custom style
- It supports addition, subtraction, multiplication and division
- more todo...

`lv_100ask_calc` is very simple to use, and the subsequent custom expansion functions are also very convenient, so stay tuned for more functions.

![](./lv_100ask_calc_demo.png)


# Usage

Refer to the example in **lv_lib_100ask/test/lv_100ask_calc_test**.

# About
This is an open project and contribution is very welcome!
Contact us: smilezyb@163.com