
<h1 align="center"> lv_100ask_memory_game</h1>

<p align="center">
<img src="./lv_100ask_memory_game_demo.gif">
</p>
<p align="center">
lv_100ask_memory_game is a memory puzzle number pair game.
</p>


**English** | [中文](./README_zh.md) |


# Introduction
**lv_100ask_memory_game** features：

- Custom level
- Custom style
- Custom background picture
- more todo...

`lv_100ask_memory_game` is very simple to use, and the subsequent custom expansion functions are also very convenient, so stay tuned for more functions.

![](/./lv_100ask_memory_game_demo.png)


# Usage

Refer to the example in **lv_lib_100ask/test/lv_100ask_memory_game_test**.

# About
This is an open project and contribution is very welcome!
Contact us: smilezyb@163.com