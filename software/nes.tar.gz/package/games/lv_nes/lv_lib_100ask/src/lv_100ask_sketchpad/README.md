
<h1 align="center"> lv_100ask_sketchpad</h1>

<p align="center">
<img src="./lv_100ask_sketchpad_demo.gif">
</p>
<p align="center">
lv_100ask_sketchpad is a lvgl page manager.
</p>


**English** | [中文](./README_zh.md) |


# Introduction
**lv_100ask_sketchpad** features：

- Custom canvas style
- Custom brush color
- Custom brush size
- more todo...

`lv_100ask_sketchpad` is very simple to use, and the subsequent custom expansion functions are also very convenient, so stay tuned for more functions.

![](/./lv_100ask_sketchpad_demo.gif)


# Usage

Refer to the example in **lv_lib_100ask/test/lv_100ask_sketchpad_test**.

# About
This is an open project and contribution is very welcome!
Contact us: smilezyb@163.com