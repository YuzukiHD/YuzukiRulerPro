
#ifndef InfoNES_MAPPER_002_H_INCLUDED
#define InfoNES_MAPPER_002_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

/*-------------------------------------------------------------------*/
/*  Include files                                                    */
/*-------------------------------------------------------------------*/

#include "../InfoNES_Types.h"



/*-------------------------------------------------------------------*/
/*  Function prototypes                                              */
/*-------------------------------------------------------------------*/

void Map2_Init();
void Map2_Write( WORD wAddr, BYTE byData );



#ifdef __cplusplus
} /*extern "C"*/
#endif


#endif
