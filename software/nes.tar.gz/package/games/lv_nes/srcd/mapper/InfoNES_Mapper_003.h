
#ifndef InfoNES_MAPPER_003_H_INCLUDED
#define InfoNES_MAPPER_003_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

/*-------------------------------------------------------------------*/
/*  Include files                                                    */
/*-------------------------------------------------------------------*/

#include "../InfoNES_Types.h"



/*-------------------------------------------------------------------*/
/*  Function prototypes                                              */
/*-------------------------------------------------------------------*/

void Map3_Init();
void Map3_Write( WORD wAddr, BYTE byData );



#ifdef __cplusplus
} /*extern "C"*/
#endif


#endif
