#include "lv_drivers/display/fbdev.h"
#include "lv_drivers/display/sunxifb.h"
#include "lv_drivers/indev/evdev.h"
#include "lvgl/lvgl.h"
#include "lv_lib_100ask/lv_lib_100ask.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
  lv_disp_drv_t disp_drv;
  lv_disp_draw_buf_t disp_buf;
  lv_indev_drv_t indev_drv;
  uint32_t rotated = LV_DISP_ROT_90;

  lv_disp_drv_init(&disp_drv);

  /*LittlevGL init*/
  lv_init();

  /*Linux frame buffer device init*/
  sunxifb_init(rotated);

  /*A buffer for LittlevGL to draw the screen's content*/
  static uint32_t width, height;
  sunxifb_get_sizes(&width, &height);

  static lv_color_t *buf;
  buf = (lv_color_t *)malloc(width * height * sizeof(lv_color_t));

  if (buf == NULL) {
    sunxifb_exit();
    printf("malloc draw buffer fail\n");
    return 0;
  }

  /*Initialize a descriptor for the buffer*/
  lv_disp_draw_buf_init(&disp_buf, buf, NULL, width * height);

  /*Initialize and register a display driver*/
  disp_drv.draw_buf = &disp_buf;
  disp_drv.flush_cb = sunxifb_flush;
  disp_drv.hor_res = width;
  disp_drv.ver_res = height;
  disp_drv.rotated = rotated;
  disp_drv.screen_transp = 0;
  lv_disp_drv_register(&disp_drv);

  evdev_init();
  lv_indev_drv_init(&indev_drv);          /*Basic initialization*/
  indev_drv.type = LV_INDEV_TYPE_POINTER; /*See below.*/
  indev_drv.read_cb = evdev_read;         /*See below.*/
  /*Register the driver in LVGL and save the created input device object*/
  lv_indev_t *evdev_indev = lv_indev_drv_register(&indev_drv);

  lv_100ask_nes_simple_test();

  /*Handle LitlevGL tasks (tickless mode)*/
  while (1) {
    lv_task_handler();
    usleep(10000);
  }

  return 0;
}

/*Set in lv_conf.h as `LV_TICK_CUSTOM_SYS_TIME_EXPR`*/
uint32_t custom_tick_get(void) {
  static uint64_t start_ms = 0;
  if (start_ms == 0) {
    struct timeval tv_start;
    gettimeofday(&tv_start, NULL);
    start_ms = (tv_start.tv_sec * 1000000 + tv_start.tv_usec) / 1000;
  }

  struct timeval tv_now;
  gettimeofday(&tv_now, NULL);
  uint64_t now_ms;
  now_ms = (tv_now.tv_sec * 1000000 + tv_now.tv_usec) / 1000;

  uint32_t time_ms = now_ms - start_ms;
  return time_ms;
}